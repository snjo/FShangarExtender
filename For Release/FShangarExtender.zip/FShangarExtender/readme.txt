Hangar Extender
by Snjo

This plugin extends the usable area when building in the SPH or VAB, so you can build outside or above the building. Useful for building large aircraft carriers or tall rockets.

Sometimes the work area scaling doesn't kick in due to bad timing. In that case press the * on the numpad to redo the scaling. This key is reconfigurable in settings.txt.
For the custom key to work, the settings.txt file MUST be placed in GameData\FShangarExtender\settings.txt

License:
Creative Commons Attribution 4.0 International.

Source: https://github.com/snjo/FShangarExtender
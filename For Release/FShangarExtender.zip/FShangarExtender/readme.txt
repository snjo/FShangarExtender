Hangar Extender
by Snjo

This plugin extends the usable area when building in the SPH or VAB, so you can build outside or above the building. Useful for building large aircraft carriers or tall rockets.
InfiniteDice's Boat Parts mod has it's own version of this module, so you will not need this if you are also using his mod.

License:
Creative Commons Attribution 4.0 International.

Source: https://github.com/snjo/FShangarExtender
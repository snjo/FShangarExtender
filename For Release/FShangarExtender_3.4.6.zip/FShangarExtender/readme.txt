Hangar Extender
by Snjo Updated by Alewx

2015-10-11 3.4.6
-Recompiled for KSP 1.0.5
2015-10-11 3.4.5
-added stock toolbar button
-slight improved hangar hiding (far from perfect)
2015-09-18 3.4.4
-added option to hide the hangar scene
-added option to enable advanced debugging output
-minimum zoom is increased by the scalingFactor
-fixed bug of the boundinglimits
2015-09-07 3.4.3
-changed code structure
-further bugfixing
2015-09-05 3.4.2
-bug fixed that would stuck all buildings and part placements
2015-09-05 3.4.1
-bug in SPH fixed
2015-09-05 3.4
-Compatibility with 1.0.4



This plugin extends the usable area when building in the SPH or VAB, so you can build outside or above the building. Useful for building large aircraft carriers or tall rockets.

To scale the Hangar press the * on the numpad. This key is reconfigurable in settings.txt.
For the custom key to work, the settings.txt file MUST be placed in GameData\FShangarExtender\settings.txt

License:
Creative Commons Attribution 4.0 International.


original Source: https://github.com/snjo/FShangarExtender
Updates Source: https://github.com/Alewx/FShangarExtender